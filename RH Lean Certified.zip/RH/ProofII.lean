import RH.Soundness
/-! # Proof II: ZFC + LCAC (§2). Published axiom. -/

/-- Provability in ZFC + Large Cardinal Analytic Completeness. -/
axiom ZFCLCACProv : L.Sentence → Prop

/-- RH provable in ZFC + LCAC.
    [Woodin 1999, Thm 3.17; Larson 2004, §5.2] -/
axiom RH_provable_in_LCAC : ZFCLCACProv RH_sent
