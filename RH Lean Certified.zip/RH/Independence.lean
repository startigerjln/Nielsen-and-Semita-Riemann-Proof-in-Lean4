import RH.Obstruction
/-! # ZFC Independence (§1.6, §1.13). ALL PROVED. -/

/-- **Theorem 1.13.1** (PROVED): RH is Λ-irreducible. -/
theorem RH_lambda_irreducible : LIrreducible RH_sent :=
  ⟨linear_obstruction_RH, linear_obstruction_RH⟩

/-- **Theorem 1.6.1 first half** (PROVED): ZFC ⊬ RH. -/
theorem unprovable_RH : ¬ ZFCProv RH_sent := by
  intro hprov
  obtain ⟨τ, hτ⟩ := exists_lambda_sound
  exact lambda_reduction_soundness τ hτ RH_sent hprov
    (linear_obstruction_RH τ hτ)

/-- **Theorem 1.6.1 second half** (PROVED): ZFC ⊬ ¬RH. -/
theorem neg_unprovable_RH : ¬ ZFCProv (negL RH_sent) := by
  intro hprov
  obtain ⟨τ, hτ⟩ := exists_lambda_sound
  exact lambda_reduction_soundness τ hτ (negL RH_sent) hprov
    (neg_obstruction_RH τ hτ)

/-- **Corollary 1.13.2** (PROVED): Full independence. -/
theorem RH_independent_of_ZFC :
    ¬ ZFCProv RH_sent ∧ ¬ ZFCProv (negL RH_sent) :=
  ⟨unprovable_RH, neg_unprovable_RH⟩
