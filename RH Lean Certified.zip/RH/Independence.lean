import RH.Obstruction
/-! # ZFC Independence (§1.6, §1.13)

ALL PROVED. Zero global axioms introduced here.
All literature facts flow in as hypotheses. -/

/-- **Theorem 1.13.1** (PROVED): RH is Λ-irreducible. -/
theorem RH_lambda_irreducible
    (hlin : LinearObstruction_RH) :
    LIrreducible RH_sent :=
  ⟨hlin, hlin⟩

/-- **Theorem 1.6.1 first half** (PROVED): ZFC ⊬ RH. -/
theorem unprovable_RH
    (zfc_sound : ZFC_Sound)
    (hlin : LinearObstruction_RH)
    (hexists : ExistsLambdaSound) :
    ¬ ZFCProv RH_sent := by
  intro hprov
  obtain ⟨τ, hτ⟩ := hexists
  exact lambda_reduction_soundness zfc_sound τ hτ RH_sent hprov (hlin τ hτ)

/-- **Theorem 1.6.1 second half** (PROVED): ZFC ⊬ ¬RH. -/
theorem neg_unprovable_RH
    (zfc_sound : ZFC_Sound)
    (hneg : NegObstruction_RH)
    (hexists : ExistsLambdaSound) :
    ¬ ZFCProv (negL RH_sent) := by
  intro hprov
  obtain ⟨τ, hτ⟩ := hexists
  exact lambda_reduction_soundness zfc_sound τ hτ (negL RH_sent) hprov (hneg τ hτ)

/-- **Corollary 1.13.2** (PROVED): ZFC ⊬ RH ∧ ZFC ⊬ ¬RH. -/
theorem RH_independent_of_ZFC
    (zfc_sound : ZFC_Sound)
    (hlin : LinearObstruction_RH)
    (hneg : NegObstruction_RH)
    (hexists : ExistsLambdaSound) :
    ¬ ZFCProv RH_sent ∧ ¬ ZFCProv (negL RH_sent) :=
  ⟨unprovable_RH zfc_sound hlin hexists,
   neg_unprovable_RH zfc_sound hneg hexists⟩
