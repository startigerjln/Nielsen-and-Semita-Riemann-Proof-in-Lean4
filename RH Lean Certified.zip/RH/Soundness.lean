import RH.Defs
/-! # Theorem 1.5.2: Λ-Reduction Soundness

This is our first PROVED theorem. It takes ZFC soundness as a
hypothesis rather than a global axiom. -/

/-- **Theorem 1.5.2** (PROVED): If ZFC is sound, then ZFC ⊢ φ ⟹ Λ(φ) vanishes.

    The proof: if ZFC proves φ, then by soundness φ is true in the model.
    By Λ-soundness, the round-trip τ.RL preserves satisfaction.
    But then zsat φ = zsat (τ.RL φ), contradicting the obstruction hypothesis. -/
theorem lambda_reduction_soundness
    (zfc_sound : ZFC_Sound)
    (τ : TranslationPair) (hτ : LambdaSound τ)
    (φ : L.Sentence) (hφ : ZFCProv φ) :
    LVanishes τ φ := by
  intro hobs
  have h1 := zfc_sound φ hφ
  have h2 := (hτ.pres φ).mp h1
  exact hobs (propext ⟨fun _ => h2, fun _ => h1⟩)
