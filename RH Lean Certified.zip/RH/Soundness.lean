import RH.Defs
/-! # Theorem 1.5.2: Λ-Reduction Soundness

This is our first PROVED theorem. It takes ZFC soundness as a
hypothesis rather than a global axiom. -/

/-- **Theorem 1.5.2** (PROVED): If ZFC is sound, then ZFC ⊢ φ ⟹ Λ(φ) vanishes.

    The proof: if ZFC proves φ, then by soundness φ is true in the model.
    By Λ-soundness (applied to the provable sentence φ), the round-trip
    τ.RL(φ) is also true.  Both being true (inhabited Props), they are
    propositionally equal, contradicting any obstruction. -/
theorem lambda_reduction_soundness
    (zfc_sound : ZFC_Sound)
    (τ : TranslationPair) (hτ : LambdaSound τ)
    (φ : L.Sentence) (hφ : ZFCProv φ) :
    LVanishes τ φ := by
  intro hobs
  have h1 := zfc_sound φ hφ           -- zsat φ  (by ZFC soundness)
  have h2 := hτ.pres φ hφ h1          -- zsat (τ.RL φ)  (Λ-soundness on provable φ)
  exact hobs (propext ⟨fun _ => h2, fun _ => h1⟩)
