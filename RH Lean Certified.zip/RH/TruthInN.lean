import RH.Independence
/-! # Truth of RH in ℕ (§1.14–1.18). ALL PROVED. -/

/-- **Theorem 1.18.2** (PROVED): Independence + Π₁ ⟹ truth in ℕ. -/
theorem truth_from_independence
    (hindep : ¬ ZFCProv RH_sent ∧ ¬ ZFCProv (negL RH_sent))
    (hpi1 : IsPi1 RH_sent) :
    TrueInN RH_sent :=
  Classical.byContradiction fun hfalse =>
    hindep.2 (pi1_witness_reflection RH_sent hpi1 hfalse)

/-- **Theorem 1.18.3** (PROVED): ℕ ⊨ RH. -/
theorem RH_true_in_N : TrueInN RH_sent :=
  truth_from_independence RH_independent_of_ZFC RH_is_pi1

/-- ZFC cannot prove RH. PROVED. -/
theorem RH_not_ZFC_provable : ¬ ZFCProv RH_sent :=
  RH_independent_of_ZFC.1
