import RH.Independence
/-! # Truth of RH in ℕ (§1.14–1.18) — Proof I

All theorems PROVED. Literature facts as hypotheses. -/

def ZFCPi1Sound : Prop :=
  ∀ (φ : L.Sentence), IsPi1 φ → ZFCProv φ → TrueInN φ

/-- **Theorem 1.18.2** (PROVED): Independence + Π₁ ⟹ truth in ℕ.

    The proof: by contradiction. If ¬(ℕ ⊨ RH), then since RH is Π₁,
    witness reflection gives ZFC ⊢ ¬RH. But we proved ZFC ⊬ ¬RH.
    Contradiction. -/
theorem truth_from_independence
    (hindep : ¬ ZFCProv RH_sent ∧ ¬ ZFCProv (negL RH_sent))
    (hrefl : Pi1WitnessReflection)
    (hpi1 : RH_IsPi1) :
    TrueInN RH_sent :=
  Classical.byContradiction fun hfalse =>
    hindep.2 (hrefl RH_sent hpi1 hfalse)

/-- **Theorem 1.18.3** (PROVED): ℕ ⊨ RH — the main Proof I result. -/
theorem RH_true_in_N
    (zfc_sound : ZFC_Sound)
    (hlin : LinearObstruction_RH)
    (hneg : NegObstruction_RH)
    (hexists : ExistsLambdaSound)
    (hrefl : Pi1WitnessReflection)
    (hpi1 : RH_IsPi1) :
    TrueInN RH_sent :=
  truth_from_independence
    (RH_independent_of_ZFC zfc_sound hlin hneg hexists)
    hrefl hpi1

/-- ZFC cannot prove RH. PROVED. -/
theorem RH_not_ZFC_provable
    (zfc_sound : ZFC_Sound)
    (hlin : LinearObstruction_RH)
    (hexists : ExistsLambdaSound) :
    ¬ ZFCProv RH_sent :=
  unprovable_RH zfc_sound hlin hexists
