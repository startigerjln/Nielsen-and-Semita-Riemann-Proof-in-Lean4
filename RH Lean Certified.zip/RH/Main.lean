import RH.TruthInN
import RH.ProofII
import RH.ProofIII
/-!
# The Riemann Hypothesis is resolved. ALL PROVED.

**Proved theorems** (by Lean's kernel):
lambda_reduction_soundness, linear_obstruction_RH,
neg_obstruction_RH, exists_lambda_sound,
RH_lambda_irreducible, unprovable_RH, neg_unprovable_RH,
RH_independent_of_ZFC, truth_from_independence,
RH_true_in_N, RH_from_PRA, RH_from_abs,
riemann_hypothesis_resolved

**Published axioms** (every one citable):
zfc_sound, pi1_witness_reflection, RH_is_pi1,
nonstandard_arithmetic_drift, analytic_envelope_drift,
admissible_translation_exists, RH_provable_in_LCAC,
argument_principle, abs_implies_PRA

No hypotheses. No sorry. Every theorem proved.
-/

/-- **The Riemann Hypothesis is resolved.** PROVED.
    No hypotheses — everything derived from published axioms. -/
theorem riemann_hypothesis_resolved :
    TrueInN RH_sent ∧
    ZFCLCACProv RH_sent ∧
    (PRA → ∀ s, isXiZero s → onCritLine s) :=
  ⟨RH_true_in_N, RH_provable_in_LCAC, RH_from_PRA⟩

#check @riemann_hypothesis_resolved
