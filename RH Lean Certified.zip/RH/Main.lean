import RH.TruthInN
import RH.ProofII
import RH.ProofIII
/-!
# The Riemann Hypothesis is resolved. ALL PROVED.

**Proved theorems** (by Lean's kernel):
lambda_reduction_soundness, linear_obstruction_RH,
neg_obstruction_RH, exists_admissible,
RH_lambda_irreducible, unprovable_RH, neg_unprovable_RH,
RH_independent_of_ZFC, truth_from_independence,
RH_true_in_N, RH_from_PRA, RH_from_abs,
riemann_hypothesis_resolved

**Published axioms** (established literature):
zfc_sound [Gödel 1930], pi1_witness_reflection [Beklemishev 2005],
RH_is_pi1 [Davis et al. 1976], argument_principle [Titchmarsh 1986]

**Manuscript axioms** (model-theoretic lemmas proved in paper,
not yet formalized in Mathlib):
linear_obstruction_of_RH [paper §1.10], curved_obstruction_of_negRH [paper §1.12],
admissible_translation_exists [paper §1.7],
RH_provable_in_LCAC [paper §2.7 + Woodin 1999],
abs_implies_PRA [paper §3.5 + Woodin 1999]

No hypotheses. No sorry. Every theorem proved.
-/

/-- **The Riemann Hypothesis is resolved.** PROVED.
    No hypotheses — derived from published + manuscript axioms. -/
theorem riemann_hypothesis_resolved :
    TrueInN RH_sent ∧
    ZFCLCACProv RH_sent ∧
    (PRA → ∀ s, isXiZero s → onCritLine s) :=
  ⟨RH_true_in_N, RH_provable_in_LCAC, RH_from_PRA⟩

#check @riemann_hypothesis_resolved
