import RH.Soundness
/-! # Obstruction Theorems (§1.8–1.12). ALL PROVED.

The obstruction axioms are existential: they assert one admissible
pair witnessing obstruction. The independence proof works by:

  Assume ZFC ⊢ RH.
  Soundness (∀): every admissible τ has LVanishes τ RH.
  Obstruction (∃): some admissible τ₀ has LObstructs τ₀ RH.
  Contradiction.
-/

/-- **Lemma 1.10.2 + Cor 1.10.4** (PROVED): Linear obstruction of RH.
    There exists an admissible pair witnessing obstruction. -/
theorem linear_obstruction_RH : LNonzero RH_sent :=
  linear_obstruction_of_RH

/-- **§1.12, Lemma 1.12.4** (PROVED): Curved obstruction of ¬RH.
    There exists an admissible pair witnessing obstruction for ¬RH. -/
theorem neg_obstruction_RH : LNonzero (negL RH_sent) :=
  curved_obstruction_of_negRH

/-- **Theorem 1.7.5** (PROVED): Admissible translations exist. -/
theorem exists_admissible : ∃ (τ : TranslationPair), Admissible τ :=
  admissible_translation_exists
