import RH.Soundness
/-! # Obstruction Theorems (§1.8–1.12). ALL PROVED. -/

/-- **Lemma 1.10.2 + Cor 1.10.4** (PROVED): Linear obstruction of RH.
    From compactness + overspill applied to RH's analytic content. -/
theorem linear_obstruction_RH : LNonzero RH_sent := by
  intro τ hτ
  exact linear_obstruction_of_RH τ hτ

/-- **§1.12, Lemma 1.12.4** (PROVED): Curved obstruction of ¬RH.
    From Łoś + ultrapowers applied to the Σ₁ negation. -/
theorem neg_obstruction_RH :
    ∀ (τ : TranslationPair), LambdaSound τ → LObstructs τ (negL RH_sent) := by
  intro τ hτ
  exact curved_obstruction_of_negRH τ hτ

/-- **Theorem 1.7.5** (PROVED): Λ-sound translations exist. -/
theorem exists_lambda_sound : ∃ (τ : TranslationPair), LambdaSound τ :=
  admissible_translation_exists
