import RH.Soundness
/-! # Obstruction Lemmas (§1.8–1.12)

No global axioms in this file.  The obstruction results are imported
as hypotheses from Defs.lean's named propositions. -/

-- This file exists purely for module organization.
-- The obstruction facts (LinearObstruction_RH, NegObstruction_RH,
-- ExistsLambdaSound) are defined as `Prop` in Defs.lean and passed
-- as hypotheses to theorems in Independence.lean.
