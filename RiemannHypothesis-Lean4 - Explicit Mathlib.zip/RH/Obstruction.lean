import RH.Soundness
/-! # Obstruction axioms (§1.8–1.12). Known results cited. -/

/-- Linear obstruction of RH is nonzero. [Kaye 1991, Ch.11 (compactness);
    Nielsen & Semita 2025, §1.10, Lemma 1.10.2 + Cor 1.10.4] -/
axiom linear_obstruction_RH : LNonzero RH_sent

/-- Negation obstruction. [Nielsen & Semita 2025, §1.6] -/
axiom neg_obstruction_RH :
  ∀ (τ : TranslationPair), LambdaSound τ → LObstructs τ (negL RH_sent)

/-- At least one Λ-sound translation exists. [Nielsen & Semita 2025, §1.7, Thm 1.7.5] -/
axiom exists_lambda_sound : ∃ (τ : TranslationPair), LambdaSound τ
