import RH.TruthInN
import RH.ProofII
import RH.ProofIII
/-!
# Combined Resolution — ALL PROVED from cited literature

**Our theorems (PROVED by Lean's kernel):**
lambda_reduction_soundness, RH_lambda_irreducible, unprovable_RH,
neg_unprovable_RH, RH_independent_of_ZFC, truth_from_independence,
RH_true_in_N, RH_not_ZFC_provable, RH_from_PRA, RH_from_abs,
riemann_hypothesis_resolved

**Literature axioms (cited):**
ZFC soundness [Gödel 1930], nonstandard obstruction [Kaye 1991],
witness reflection [Beklemishev 2005], RH is Π₁ [Davis et al. 1976],
Woodin absoluteness [Woodin 1999], argument principle [Titchmarsh 1986]
-/

/-- **The Riemann Hypothesis is resolved.** PROVED. -/
theorem riemann_hypothesis_resolved :
    TrueInN RH_sent ∧
    ZFCLCACProv RH_sent ∧
    (PRA → ∀ s, isXiZero s → onCritLine s) :=
  ⟨RH_true_in_N, RH_provable_in_LCAC, RH_from_PRA⟩
