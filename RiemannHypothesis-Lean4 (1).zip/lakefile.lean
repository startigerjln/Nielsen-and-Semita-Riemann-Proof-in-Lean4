import Lake
open Lake DSL

package «RH» where
  leanOptions := #[
    ⟨`autoImplicit, false⟩
  ]

@[default_target]
lean_lib «RH» where
  srcDir := "RH"
