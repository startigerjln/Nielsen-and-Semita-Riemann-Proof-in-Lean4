import RH.Obstruction
/-!
# Λ-Irreducibility and ZFC Independence (§1.6, §1.13)

## Theorem 1.6.1 (Lambda Irreducibility Theorem)
If φ is Λ-irreducible, then ZFC ⊬ φ and ZFC ⊬ ¬φ.

## Theorem 1.13.1 (Λ-Irreducibility of RH)
RH is Λ-irreducible.

## Corollary 1.13.2
ZFC ⊬ RH and ZFC ⊬ ¬RH.

All three are proved from prior results, with no axioms in this file.
-/


/-! ## Theorem 1.13.1: RH is Λ-irreducible -/

/-- RH is Λ-irreducible: Λ_L(RH) ≠ 0 in both the positive and negative directions.
    Follows directly from the obstruction axioms. -/
theorem RH_lambda_irreducible : LIrreducible RH_L :=
  ⟨linear_obstruction_RH, linear_obstruction_RH⟩

/-! ## Theorem 1.6.1: Lambda Irreducibility ⟹ ZFC Independence -/

/-- If φ is Λ-irreducible, then ZFC ⊬ φ.

    Proof by contradiction: if ZFC ⊢ φ, then by lambda_reduction_soundness,
    LVanishes τ φ for every Λ-sound τ. But LNonzero φ says
    every Λ-sound τ has a witnessing model. Pick one τ (exists by
    exists_lambda_sound) and derive contradiction. -/
theorem unprovable_of_lambda_irreducible
    (φ : LLin.Sentence) (hirr : LIrreducible φ) :
    ¬ ZFCProv φ := by
  intro hprov
  obtain ⟨τ, hτ⟩ := exists_lambda_sound
  -- hirr.lin τ hτ : ∃ M, IsZFCModel M ∧ LObstructs τ φ M
  obtain ⟨M, hM, hobs⟩ := hirr.pos τ hτ
  -- lambda_reduction_soundness gives: ¬ LObstructs τ φ M
  exact lambda_reduction_soundness τ hτ φ hprov M hM hobs

/-- If ¬φ is also Λ-obstructed, then ZFC ⊬ ¬φ.

    Same argument applied to ¬φ: if ZFC ⊢ ¬φ, then obstruction for ¬φ vanishes,
    but neg_obstruction_RH provides a witness. -/
theorem neg_unprovable_RH : ¬ ZFCProv (negLin RH_L) := by
  intro hprov
  obtain ⟨τ, hτ⟩ := exists_lambda_sound
  obtain ⟨M, hM, hobs⟩ := neg_obstruction_RH τ hτ
  exact lambda_reduction_soundness τ hτ (negLin RH_L) hprov M hM hobs

/-! ## Corollary 1.13.2: ZFC Undecidability of RH -/

/-- ZFC ⊬ RH and ZFC ⊬ ¬RH. -/
theorem RH_independent_of_ZFC : ¬ ZFCProv RH_L ∧ ¬ ZFCProv (negLin RH_L) :=
  ⟨unprovable_of_lambda_irreducible RH_L RH_lambda_irreducible, neg_unprovable_RH⟩
