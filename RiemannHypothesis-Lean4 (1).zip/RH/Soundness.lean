import RH.Defs
/-!
# Theorem 1.5.2: Λ-Reduction Soundness
ZFC ⊢ φ ⟹ Λ(φ) = 0.
-/

axiom zfc_sound :
  ∀ (φ : LLin.Sentence) (M : FStruct LLin),
    ZFCProv φ → IsZFCModel M → msat modLin M φ

theorem lambda_reduction_soundness
    (τ : TranslationPair) (hτ : LambdaSound τ)
    (φ : LLin.Sentence) (hφ : ZFCProv φ) :
    LVanishes τ φ := by
  intro M hM hobs
  have h1 : msat modLin M φ := zfc_sound φ M hφ hM
  have h2 : msat modLin M (τ.RL φ) := (hτ.pres φ M hM).mp h1
  have : msat modLin M φ = msat modLin M (τ.RL φ) :=
    propext ⟨fun _ => h2, fun _ => h1⟩
  exact hobs this
