import RH.Independence
/-!
# Truth of RH in the Standard Model (§1.14–1.18)

## Theorem 1.18.2 (Truth from Independence)
If ZFC is Π₁-sound, ZFC ⊬ RH, ZFC ⊬ ¬RH, and RH is Π₁, then N ⊨ RH.

## Theorem 1.18.3 (Main Result of Proof I)
The Riemann Hypothesis is true in the standard model of arithmetic.

Both proved from the axioms below + the independence result.
-/


/-! ## Π₁-Soundness -/

/-- ZFC is Π₁-sound: if ZFC ⊢ φ and φ is Π₁, then N ⊨ φ.
    This is a standard metatheoretic assumption, strictly weaker than
    ZFC proving its own consistency (compatible with Gödel's Second
    Incompleteness Theorem). See §1.14, Theorem 1.14.1. -/
def ZFCPi1Sound : Prop :=
  ∀ (φ : LLin.Sentence), IsPi1 φ → ZFCProv φ → TrueInN φ

/-! ## Witness Reflection (Theorem 1.17.1)

If a Π₁ sentence ∀n φ(n) is false in N, then there exists n₀ with ¬φ(n₀),
and since φ is Δ₀ (decidable and absolute), ZFC proves ¬φ(n̄₀),
hence ZFC ⊢ ¬(∀n φ(n)).

This is the key link: falsity in N ⟹ ZFC-refutability for Π₁ sentences. -/
axiom pi1_witness_reflection :
  ∀ (φ : LLin.Sentence), IsPi1 φ → ¬ TrueInN φ → ZFCProv (negLin φ)

/-! ## RH is Π₁ (Proposition 1.18.1) -/

axiom RH_is_pi1 : IsPi1 RH_L

/-! ## Theorem 1.18.2: Truth from Independence -/

/-- If ZFC is Π₁-sound, RH is ZFC-independent, and RH is Π₁, then N ⊨ RH.

    Proof by contradiction:
    - Suppose ¬(N ⊨ RH).
    - By witness reflection (since RH is Π₁), ZFC ⊢ ¬RH.
    - But RH is ZFC-independent, so ZFC ⊬ ¬RH.
    - Contradiction. -/
theorem truth_from_independence
    (_hsound : ZFCPi1Sound)
    (hindep : ¬ ZFCProv RH_L ∧ ¬ ZFCProv (negLin RH_L))
    (hpi1 : IsPi1 RH_L) :
    TrueInN RH_L :=
  Classical.byContradiction fun hfalse =>
    -- By witness reflection: ¬(N ⊨ RH) ⟹ ZFC ⊢ ¬RH
    let hprov_neg := pi1_witness_reflection RH_L hpi1 hfalse
    -- But ZFC ⊬ ¬RH by independence
    hindep.2 hprov_neg

/-! ## Theorem 1.18.3: Main Result of Proof I -/

/-- The Riemann Hypothesis is true in the standard model of arithmetic.

    Proof: Combine
    1. RH is ZFC-independent (Corollary 1.13.2 = RH_independent_of_ZFC)
    2. RH is Π₁ (Proposition 1.18.1 = RH_is_pi1)
    3. Theorem 1.18.2 (truth_from_independence) -/
theorem RH_true_in_N (hsound : ZFCPi1Sound) : TrueInN RH_L :=
  truth_from_independence hsound RH_independent_of_ZFC RH_is_pi1

/-- The ZFC-independence of RH is an essential premise.
    This is NOT an internal derivation of RH within ZFC. -/
theorem RH_not_ZFC_provable : ¬ ZFCProv RH_L :=
  RH_independent_of_ZFC.1
