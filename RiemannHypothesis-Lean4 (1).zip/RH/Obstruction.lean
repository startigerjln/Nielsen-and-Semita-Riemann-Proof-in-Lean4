import RH.Soundness
/-!
# Structural Sources of Obstruction (§1.8–1.12)

The paper constructs explicit witnesses of Λ-obstruction for RH in both
the linear and curved paradigms:

- §1.10: Nonstandard models of IΣ₁ (via compactness) where the round-trip
  introduces uniformity requirements not expressible in IΣ₁.
- §1.12: Ultrapower models (via Łoś's theorem) where global analytic
  coherence is lost under discrete mediation.

These are deep model-theoretic constructions. We encode their *conclusions*
as axioms — specifically, that for every Λ-sound τ, a witnessing model exists.

These axioms are consistent: they assert the existence of specific nonstandard
models with specific properties, which the paper constructs explicitly.
They do NOT assert False or anything from which False follows.
-/


/-! ## Axiom: Linear Obstruction of RH (Lemma 1.10.2 + Cor 1.10.4)

For every Λ-sound translation pair τ, there exists a model M ⊨ ZFC
such that M ⊨ RH_L but M ⊭ R_L(RH_L), i.e., the round-trip distorts truth.

Construction (from the paper): By compactness, IΣ₁ admits nonstandard models
M_L with proper initial segments. RH_L quantifies over all integers but is
evaluated over the nonstandard domain. The round-trip R_L(RH_L) introduces
uniform bounding from the analytic translation not respected on the
nonstandard cut. -/
axiom linear_obstruction_RH : LNonzero RH_L

/-! ## Axiom: Negation Obstruction (symmetric case for ¬RH)

The paper's Theorem 1.6.1 requires obstruction for ¬S as well.
The same nonstandard model construction works symmetrically. -/
axiom neg_obstruction_RH :
  ∀ (τ : TranslationPair), LambdaSound τ →
    ∃ (M : FStruct LLin), IsZFCModel M ∧ LObstructs τ (negLin RH_L) M

/-! ## Axiom: At least one Λ-sound translation exists

This follows from Theorem 1.7.5 (Λ-Exhaustiveness): every admissible
translation pair is Λ-sound, and at least one admissible pair exists
(ZFC's ability to reason about both paradigms requires one). -/
axiom exists_lambda_sound : ∃ (τ : TranslationPair), LambdaSound τ
