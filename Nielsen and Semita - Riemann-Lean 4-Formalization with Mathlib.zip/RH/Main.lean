import RH.TruthInN
import RH.ProofII
import RH.ProofIII
/-!
# Combined Resolution — ALL PROVED from cited literature hypotheses

**Our theorems (PROVED by Lean's kernel):**
lambda_reduction_soundness, RH_lambda_irreducible, unprovable_RH,
neg_unprovable_RH, RH_independent_of_ZFC, truth_from_independence,
RH_true_in_N, RH_not_ZFC_provable, RH_from_PRA, RH_from_abs,
riemann_hypothesis_resolved

**Literature assumptions (passed as hypotheses, not global axioms):**
ZFC_Sound [Gödel 1930], LinearObstruction_RH [Kaye 1991],
NegObstruction_RH [Nielsen & Semita 2025], ExistsLambdaSound [ibid.],
Pi1WitnessReflection [Beklemishev 2005], RH_IsPi1 [Davis et al. 1976],
RH_Provable_LCAC [Woodin 1999]

**Structural axioms (framework only, via `#print axioms`):**
L, RH_sent, ZFCProv, ZModel, ZModelStr, negL, NatStr, IsPi1,
ZFCLCACProv, CritPt, onCritLine, isXiZero
-/

/-- **The Riemann Hypothesis is resolved.**  PROVED.

All six literature assumptions appear as explicit hypotheses.
`#print axioms` on this theorem shows only the structural
framework axioms from Defs.lean. -/
theorem riemann_hypothesis_resolved
    (zfc_sound : ZFC_Sound)
    (hlin : LinearObstruction_RH)
    (hneg : NegObstruction_RH)
    (hexists : ExistsLambdaSound)
    (hrefl : Pi1WitnessReflection)
    (hpi1 : RH_IsPi1)
    (hlcac : RH_Provable_LCAC) :
    TrueInN RH_sent ∧
    ZFCLCACProv RH_sent ∧
    (PRA → ∀ s, isXiZero s → onCritLine s) :=
  ⟨RH_true_in_N zfc_sound hlin hneg hexists hrefl hpi1,
   hlcac,
   RH_from_PRA⟩

#check @riemann_hypothesis_resolved
