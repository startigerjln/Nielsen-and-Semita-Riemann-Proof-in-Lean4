import RH.Defs
/-!
# Theorem 1.5.2: Λ-Reduction Soundness
ZFC ⊢ φ ⟹ Λ(φ) = 0.
-/

/-- ZFC is sound: if ZFC ⊢ φ then M ⊨ φ for all M ⊨ ZFC.
    [Gödel 1930, Completeness Theorem; Shoenfield 1967, §4.5] -/
axiom zfc_sound :
  ∀ (φ : LLin.Sentence) (M : FStruct LLin),
    ZFCProv φ → IsZFCModel M → msat modLin M φ

/-- **Theorem 1.5.2 (Λ-Reduction Soundness)** [Nielsen & Semita 2025, §1.5]
    PROVED from zfc_sound + LambdaSound.pres. -/
theorem lambda_reduction_soundness
    (τ : TranslationPair) (hτ : LambdaSound τ)
    (φ : LLin.Sentence) (hφ : ZFCProv φ) :
    LVanishes τ φ := by
  intro M hM hobs
  have h1 : msat modLin M φ := zfc_sound φ M hφ hM
  have h2 : msat modLin M (τ.RL φ) := (hτ.pres φ M hM).mp h1
  have : msat modLin M φ = msat modLin M (τ.RL φ) :=
    propext ⟨fun _ => h2, fun _ => h1⟩
  exact hobs this
