import RH.Independence
/-!
# Truth of RH in the Standard Model (§1.14–1.18) — Proof I

Three theorems PROVED, two axioms cited.
-/

/-- ZFC is Π₁-sound: provable Π₁ sentences are true in ℕ.
    [Beklemishev 2005; standard metatheoretic assumption, see §1.14] -/
def ZFCPi1Sound : Prop :=
  ∀ (φ : LLin.Sentence), IsPi1 φ → ZFCProv φ → TrueInN φ

/-- **Theorem 1.17.1 (Π₁ Witness Reflection)**: If a Π₁ sentence is false in ℕ,
    then ZFC proves its negation.
    Follows from: Δ₀ absoluteness [Shoenfield 1967, §4.6], Σ₁-completeness
    of ZFC [Beklemishev 2005], and the fact that φ_RH is primitive recursive
    [Davis, Matiyasevich & Robinson 1976]. -/
axiom pi1_witness_reflection :
  ∀ (φ : LLin.Sentence), IsPi1 φ → ¬ TrueInN φ → ZFCProv (negLin φ)

/-- **Proposition 1.18.1**: RH is a Π₁ sentence.
    The Mertens function M(x) = Σ_{n≤x} μ(n) yields a primitive recursive
    predicate φ_RH(n), and RH ↔ ∀n φ_RH(n).
    [Davis, Matiyasevich & Robinson 1976; Borwein et al. 2008, §2.4;
     Matiyasevich 1993] -/
axiom RH_is_pi1 : IsPi1 RH_L

/-- **Theorem 1.18.2 (Truth from Independence)**:
    PROVED by Classical.byContradiction:
    ¬(ℕ ⊨ RH) ⟹ ZFC ⊢ ¬RH (witness reflection) ⟹ contradiction with independence. -/
theorem truth_from_independence
    (_hsound : ZFCPi1Sound)
    (hindep : ¬ ZFCProv RH_L ∧ ¬ ZFCProv (negLin RH_L))
    (hpi1 : IsPi1 RH_L) :
    TrueInN RH_L :=
  Classical.byContradiction fun hfalse =>
    let hprov_neg := pi1_witness_reflection RH_L hpi1 hfalse
    hindep.2 hprov_neg

/-- **Theorem 1.18.3 (Metamathematical Truth of RH)**:
    The Riemann Hypothesis is true in the standard model ℕ.
    PROVED from: RH_independent_of_ZFC (Cor 1.13.2) + RH_is_pi1 (Prop 1.18.1)
    + truth_from_independence (Thm 1.18.2). -/
theorem RH_true_in_N (hsound : ZFCPi1Sound) : TrueInN RH_L :=
  truth_from_independence hsound RH_independent_of_ZFC RH_is_pi1

/-- ZFC cannot prove RH. Direct consequence of independence. -/
theorem RH_not_ZFC_provable : ¬ ZFCProv RH_L :=
  RH_independent_of_ZFC.1
