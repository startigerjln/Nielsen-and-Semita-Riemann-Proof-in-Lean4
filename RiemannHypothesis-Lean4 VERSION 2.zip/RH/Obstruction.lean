import RH.Soundness
/-!
# Structural Sources of Obstruction (§1.8–1.12)

Each axiom below is a consequence of known results cited in the paper.
-/

/-- **Lemma 1.10.2 + Corollary 1.10.4**: Linear obstruction of RH is nonzero.
    Constructed via compactness: IΣ₁ admits nonstandard models [Kaye 1991, Ch. 11]
    where round-trip translation introduces uniform bounds not expressible in IΣ₁.
    [Nielsen & Semita 2025, §1.10] -/
axiom linear_obstruction_RH : LNonzero RH_L

/-- **Symmetric obstruction for ¬RH**: same nonstandard model construction
    applied to the negation. [Nielsen & Semita 2025, §1.6, §1.10] -/
axiom neg_obstruction_RH :
  ∀ (τ : TranslationPair), LambdaSound τ →
    ∃ (M : FStruct LLin), IsZFCModel M ∧ LObstructs τ (negLin RH_L) M

/-- **Theorem 1.7.5 (Λ-Exhaustiveness)**: At least one Λ-sound translation exists.
    Every admissible translation pair within ZFC is Λ-sound; ZFC's ability to
    reason about both paradigms requires at least one such pair to exist.
    [Nielsen & Semita 2025, §1.7, Lemmas 1.7.1–1.7.4] -/
axiom exists_lambda_sound : ∃ (τ : TranslationPair), LambdaSound τ
