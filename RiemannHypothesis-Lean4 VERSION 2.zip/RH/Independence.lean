import RH.Obstruction
/-!
# Λ-Irreducibility and ZFC Independence (§1.6, §1.13)

All four theorems in this file are PROVED — zero axioms here.
-/

/-- **Theorem 1.13.1**: RH is Λ-irreducible.
    PROVED from linear_obstruction_RH. -/
theorem RH_lambda_irreducible : LIrreducible RH_L :=
  ⟨linear_obstruction_RH, linear_obstruction_RH⟩

/-- **Theorem 1.6.1 (first half)**: Λ-irreducibility implies ZFC unprovability.
    PROVED by contradiction: provability ⟹ vanishing (Thm 1.5.2) contradicts
    nonzero obstruction. -/
theorem unprovable_of_lambda_irreducible
    (φ : LLin.Sentence) (hirr : LIrreducible φ) :
    ¬ ZFCProv φ := by
  intro hprov
  obtain ⟨τ, hτ⟩ := exists_lambda_sound
  obtain ⟨M, hM, hobs⟩ := hirr.pos τ hτ
  exact lambda_reduction_soundness τ hτ φ hprov M hM hobs

/-- **Theorem 1.6.1 (second half)**: ¬RH is also ZFC-unprovable.
    PROVED by same argument applied to negation. -/
theorem neg_unprovable_RH : ¬ ZFCProv (negLin RH_L) := by
  intro hprov
  obtain ⟨τ, hτ⟩ := exists_lambda_sound
  obtain ⟨M, hM, hobs⟩ := neg_obstruction_RH τ hτ
  exact lambda_reduction_soundness τ hτ (negLin RH_L) hprov M hM hobs

/-- **Corollary 1.13.2**: ZFC ⊬ RH and ZFC ⊬ ¬RH.
    PROVED by combining the two halves. -/
theorem RH_independent_of_ZFC : ¬ ZFCProv RH_L ∧ ¬ ZFCProv (negLin RH_L) :=
  ⟨unprovable_of_lambda_irreducible RH_L RH_lambda_irreducible, neg_unprovable_RH⟩
